
#ifndef FUNCTIONS_Z_INCLUDED
#define FUNCTIONS_Z_INCLUDED
#define RAND_STR "ABCDEFGHIGKLMNOPQRSTUVWXYZabcdefghigklmnopqrstuvwxyz0987654321!@#$^&*(){}:|?><"



void random_string(int leng,char* word);
void crypter(char* e);
void crypt(char* pass);
#endif


